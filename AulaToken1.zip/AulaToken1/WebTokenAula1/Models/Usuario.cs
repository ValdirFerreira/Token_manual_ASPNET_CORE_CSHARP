﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebTokenAula1.Models
{
    [Table("Usuario")]
    public class Usuario
    {
        [Column("ID")]
        public int Id { get; set; }

        [Column("EMAIL")]
        public string Email { get; set; }

        [Column("SENHA")]
        public string Senha { get; set; }

        public Token Token { get; set; }
    }
}
